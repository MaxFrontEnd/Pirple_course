Vue.component("headervue", {
  template: `
  <div class="header">
    <p class="header-article">Pirple.com course -  &copy; Maxim Samohvalov</p>
  </div>`
});

var app = new Vue({
  el: "#app"
});
