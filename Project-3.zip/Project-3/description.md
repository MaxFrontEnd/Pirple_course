# Usage description

## Create elevators from Class Elevator

## Specify floors for created elevators

    - Turn on elevators with function - **powerOn**
    - Turn of elevators whth function - **powerOf**

### Call Elevator

    - Use **SelectCallElevator** function to choose what elevator will be called

    - Insert
    - If elevators are emergencyStoped - engeneers must be called
    - If Elevator not constructed to go to ths destenation floor? another elevator its called

### Move Elevator

    - Use **moveElevator** function when button is pressed inside elevator
    - Specify what elevator is used
    - Select destination floor
