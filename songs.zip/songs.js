/*
this file discribe my favorit song
list of variables with pararmeters
*/

// song and artist genre
var genre = "Rock";
//name of the group
var artist = "Korn";
//album where the song presents
var album = "Untouchables";
//song
var song = "No One's There";
// position it album
var albumPosition = 14;
// duration in seconds
var duration = 304;

/*
console.log
display all variables
*/
console.log(genre);
console.log(artist);
console.log(album);
console.log(song);
console.log(albumPosition);
console.log(duration);
